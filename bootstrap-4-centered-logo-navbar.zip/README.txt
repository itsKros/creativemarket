A Pen created at CodePen.io. You can find this one at https://codepen.io/mmgolden/pen/JNewdL.

 Centered logo on large screens using Bootstrap 4 navigation 