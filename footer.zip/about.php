<?php include('header.php'); ?>
<!-- Hero Section -->
<section id="pageTitleSec" class="inGrid">
  <div class="container">
    <div class="row">
      <div class="col-md-8 content">
        <h1>About Us</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab sint asperiores voluptate
          doloremque deserunt at sed quidem.</p>
        
      </div>
    </div>
  </div>
</section>


<!-- Welcome Section -->
<section id="abtWelSec" class="inGrid">
  <div class="container">
    <div class="row">
      <div class="col-md-4 content">
        <div class="seprator"></div>
      </div>
      <div class="col-md-8 content">
        <h6>ABOUT CREATIVE MARKET</h6>
        <h2>Creative Market Introduction</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut accumsan quam in diam porta, quis hendrerit urna eleifend. Cras eget velit non leo malesuada ullamcorper. Phasellus facilisis et dui id maximus. Proin sit amet egestas lorem. Aenean vitae vestibulum nibh. Sed at vestibulum enim, a gravida ligula. Suspendisse id nulla nec urna. Suspendisse id nulla nec urna semper cursus quis eu ligula. Etiam eget tristique purus, vel pulvinar enim. Vestibulum feugiat risus eu vehicula aliquam. Maecenas eu interdum risus. Pellentesque porttitor est in nisl Suspendisse id nulla nec urna semper cursus quis eu ligula. </p>
      </div>
      <div class="emptyspace"></div>
      <div class="col-md-4 content">
        <div class="seprator"></div>
      </div>
      <div class="col-md-8 content">
        <h6>WHY CHOOSE US</h6>
        <h2>Exceptional images deserve<br> exceptional presentation.</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut accumsan quam in diam porta, quis hendrerit urna eleifend. Cras eget velit non leo malesuada ullamcorper. Phasellus facilisis et dui id maximus. Proin sit amet egestas lorem. Aenean vitae vestibulum nibh. Sed at vestibulum enim, a gravida ligula. Suspendisse id nulla nec urna. Suspendisse id nulla nec urna semper cursus quis eu ligula. Etiam eget tristique purus, vel pulvinar enim. Vestibulum feugiat risus eu vehicula aliquam. Maecenas eu interdum risus. Pellentesque porttitor est in nisl Suspendisse id nulla nec urna semper cursus quis eu ligula. </p>
      </div>
    </div>
  </div>
</section>


<!-- Brief Section -->
<section id="abtBriefSec" class="inGrid">
  <div class="container-fluid">
    <div class="row bflex rightimg">
      <div class="col-md-6 consection">
        <h6>Jone Doe</h6>
        <h2>Letter From Founder</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut accumsan quam in diam porta, quis hendrerit urna eleifend. Cras eget velit non leo malesuada ullamcorper. Phasellus facilisis et dui id maximus. Proin sit amet egestas lorem. Aenean vitae vestibulum nibh. Sed at vestibulum enim, a gravida ligula. Suspendisse id nulla nec urna. Suspendisse id nulla nec urna semper cursus quis eu ligula. Etiam eget tristique purus, vel pulvinar enim. Vestibulum feugiat risus eu vehicula aliquam. Maecenas eu interdum risus.</p>
      </div>
      <div class="col-md-6 image">
        
      </div>
    </div>
  </div>
</section>

<?php include('footer.php'); ?>
