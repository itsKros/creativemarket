<!--Left Side Bar starts-->
<div class="col-lg-3 col-md-3 col-sm-12 myacc">
    <div class="card bg-light mb-3">
        <div class="card-header  text-white text-uppercase">Hello, Jon</div>
        <ul class="list-group myacc_block">
            <li class="list-group-item"><a href="myaccount.php">Dashboard </a></li>
            <li class="list-group-item"><a href="myacc-order.php">Orders</a></li>
            <li class="list-group-item"><a href="myacc-address.php">Addresses</a></li>
            <li class="list-group-item"><a href="myacc-account-details.php">Account Details</a></li>
            <li class="list-group-item"><a href="#">Logout </a></li>
        </ul>
    </div>
</div>
<!--Left Side Bar Ends-->